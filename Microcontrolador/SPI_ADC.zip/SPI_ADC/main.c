/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB� Code Configurator

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB� Code Configurator - v2.25.2
        Device            :  PIC16LF1703
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 v1.34
        MPLAB             :  MPLAB X v2.35 or v3.00
 */

/*
Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#include "mcc_generated_files/mcc.h"



uint16_t valor;
uint32_t lectura;
#define _SS LATCbits.LATC2

//Funci�n para escribir en eeprom
void escribir (unsigned char addr, uint32_t data){
    _SS = 0;
    addr = addr << 1;
    __delay_us(20);

    SPI_Exchange8bit(0x40);
    SPI_Exchange8bit(addr);
    
    SPI_Exchange8bit(data >> 24);
    SPI_Exchange8bit(data >> 16);
    SPI_Exchange8bit(data >> 8);
    SPI_Exchange8bit(data);
    
    __delay_us(20);
    _SS = 1;
}

//Funci�n para escribir en registro
void escribirRegistro (unsigned char addr, unsigned char data){
    _SS = 0;
    __delay_us(100);

    SPI_Exchange8bit(addr);

    SPI_Exchange8bit(data);
    
    __delay_us(100);
    _SS = 1;
}

//Funci�n para leer de eeprom
uint32_t leer (unsigned char addr){
    uint32_t data = 0;
    
    _SS = 0;
    addr = addr << 1;
    __delay_us(100); //necesaria mas espera para leer
    SPI_Exchange8bit(0x7F);
    SPI_Exchange8bit(addr);
    
    data=SPI_Exchange8bit(0x00);
    data = (data << 8)+ SPI_Exchange8bit(0x00);
    data = (data << 8)+ SPI_Exchange8bit(0x00);
    data = (data << 8)+ SPI_Exchange8bit(0x00);
 
    __delay_us(100);
    _SS = 1;
    
    return data;
}


//Funci�n para leer de un registro
unsigned char leerRegistro (unsigned char addr){
    unsigned char reg;

    _SS = 0;
    addr = addr + 0x20;
    __delay_us(20);
    
    SPI_Exchange8bit(addr);
    reg=SPI_Exchange8bit(0x00);
   
    __delay_us(20);
    _SS = 1;
    
    return reg;
}


//Funci�n para leer un dato del convertidor ADC y escribirlo en una posici�n de la eeprom
void escribirADC(unsigned char addr){
    
    while (1){
        valor = ADC_GetConversion(channel_AN3);

        //Ejemplo de escritura al sobrepasar 500 el valor leido(se enciende LED)
        if (valor > 500){
            LATAbits.LATA5=1;
            escribir(addr, valor);
            __delay_us(100);
            escribir(addr, valor); //Se hace doble escritura para asegurarlo(ha habido fallos con uno s�lo)

            return;

        }else{
            LATAbits.LATA5=0;
        }
    }
}


/*
                         Main application
 */
void main(void) {
    // initialize the device
    SYSTEM_Initialize();
    ADC_Initialize();
    SPI_Initialize();
    
    //inicializamos variables
    _SS = 1;
    LATAbits.LATA5=0;
    lectura=0x00;
    valor=0x00;
    
    __delay_ms(100);


    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    //INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    
    
    //Escribimos en la posici�n de memoria 0x0A el valor del convertidor
    escribirADC(0x0A);


    while (1) {
        // Add your application code
        /*/
        valor = ADC_GetConversion(channel_AN3);
        
        if (valor > 500){
            LATAbits.LATA5=1;
        }else{
            LATAbits.LATA5=0;
        }

        */
        //escribir(0x0A,0x333333);
        
        //__delay_us(200);
      
        //lectura = leer(0x0A);
        


        //lectura = leer(0x08);
        //__delay_us(200);
        
 
    }
}
/**
 End of File
 */